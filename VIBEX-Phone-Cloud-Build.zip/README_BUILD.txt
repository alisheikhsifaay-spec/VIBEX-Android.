VIBEX Android wrapper project

This is an Android Studio project containing the VIBEX website inside an Android WebView.
It is source code, not a compiled APK.

Build an APK:
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location (usually app/build/outputs/apk/debug/app-debug.apk).

Notes:
- Internet permission is enabled for online catalogue search.
- JavaScript, local browser storage, audio playback and file selection are enabled.
- Test on your Android phone before sharing.
- For public release, create a signed release APK/AAB using Build > Generate Signed Bundle / APK.
